package mar17;

public class Motor {

    private int potencia;
    private int cilindrada;


    public void incrementarRPM() {

        //meter mas comb en cilindros

    }

    public void decrementarRPM() {

        //meter menos comb en cilindros

    }

}
