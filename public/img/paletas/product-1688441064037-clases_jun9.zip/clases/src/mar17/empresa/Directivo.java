package mar17.empresa;

public class Directivo {

    private Auto autoDesignado;

}
