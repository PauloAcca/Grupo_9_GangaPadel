package mar17.empresa;

import mar17.direccion.Persona;

public class Auto {

    private String marca;
    private String modelo;

    private Persona conductor;


    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Persona getConductor() {
        return conductor;
    }

    public void setConductor(Persona conductor) {
        this.conductor = conductor;
    }

//    public String toString() {
//        return "mi auto es marca:" + this.marca + " y modelo " + this.modelo;
//    }

    @Override
    public String toString() {
        return "Auto{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", conductor=" + conductor +
                '}';
    }
}
