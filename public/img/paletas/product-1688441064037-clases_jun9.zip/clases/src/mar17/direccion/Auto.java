package mar17.direccion;


import mar17.ordinalidad.Engranaje;

public class Auto {

    private Engranaje e;

    private String marca;
    private String modelo;

    private Persona conductor;


    public void asignarMarca(String marca) {
        this.marca = marca;
    }
    public void asignarModelo(String modelo) {
        this.modelo = modelo;
    }

    public void asignarConductor(Persona conductor) {
        this.conductor = conductor;
    }

    public String decirMarca() {
        return this.marca;
    }
}
