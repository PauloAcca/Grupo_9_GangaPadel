package mar17.direccion;

public class Persona {

    private String nombre;
    private String legajo;

    private Auto autoAsignado;

    public void nombrar(String n) {
        this.nombre = n;
    }

    public void asignarLegajo(String l) {
        legajo = l;
    }

    public void asignarAuto(Auto a) {
        this.autoAsignado = a;
    }

    public Auto decirAutoAsignado() {
        return this.autoAsignado;
    }


}
