package mar17.direccion;

public class Empresa {


    public static void main(String[] args) {

        Persona p = new Persona();
        p.nombrar("pepe");
        p.asignarLegajo("123A789");

        Auto auto = new Auto();

        auto.asignarConductor(p);

        auto.asignarMarca("fiat");
        auto.asignarModelo("uno");

        p.asignarAuto(auto);

        Auto elAuto = p.decirAutoAsignado();
        System.out.println(elAuto.decirMarca());

    }


}
