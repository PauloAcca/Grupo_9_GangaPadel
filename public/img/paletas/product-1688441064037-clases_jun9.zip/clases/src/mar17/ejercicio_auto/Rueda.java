package mar17.ejercicio_auto;

public class Rueda {

    private int radio;
    private String color;
    private String material;


    public int getRadio() {
        return this.radio;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String girar() {
        return "estoy girando";
    }
}
