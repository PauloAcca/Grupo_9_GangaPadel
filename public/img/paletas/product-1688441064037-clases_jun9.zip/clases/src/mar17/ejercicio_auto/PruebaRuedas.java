package mar17.ejercicio_auto;

public class PruebaRuedas {

    public static void main(String[] args) {
        Rueda r = new Rueda();
        System.out.println(r.girar());



    }

}
