package mar17.ejercicio_auto;

public class Pista {

    public static void main(String[] args) {

        Auto a = new Auto();

        Motor m = new Motor();
        a.setMotor(m);


        System.out.println("el auto del campeon tiene motor marca:");
        System.out.println(a.getMotor().getMarca());

        System.out.println(a.acelerar());




    }

}
