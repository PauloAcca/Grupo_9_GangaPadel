package mar17.ejercicio_auto;

public class Motor {

    private String marca;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String aumentarRPM() {
        return "RPM AL MAXIMO!";
    }
}
