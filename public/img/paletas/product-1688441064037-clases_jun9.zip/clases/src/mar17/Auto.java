package mar17;

public class Auto {

    private String marca;
    private String modelo;

    private Motor motor;

    public void incrementarVelocidad() {

        motor.incrementarRPM();

    }

    public void decrementarVelocidad() {

    }

    public void cambiarDireccion() {

    }

}
