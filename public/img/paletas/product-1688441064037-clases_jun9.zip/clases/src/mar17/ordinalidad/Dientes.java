package mar17.ordinalidad;

public class Dientes {

    private int alto;
    private int angulo;

    public void establecerAlto(int altura) {
        this.alto = altura;
    }

    public void establecerAAngulo(int alfa) {
        this.angulo = alfa;
    }

}
