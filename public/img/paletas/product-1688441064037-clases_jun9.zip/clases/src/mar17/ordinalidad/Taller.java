package mar17.ordinalidad;

public class Taller {

    public static void main(String[] args) {

        Engranaje e = new Engranaje();

        e.maquinarEngranaje();


    }
}
