package mar17.ordinalidad;

public class Engranaje {

    private int diametro;

    private Dientes dientes = new Dientes();


    public void maquinarEngranaje() {
        this.dientes.establecerAlto(40);
        this.dientes.establecerAAngulo(5);
    }

}

class Maquina {
    private String marca;
}
