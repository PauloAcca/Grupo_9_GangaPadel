package mar17;

public class Pista {

    public static void main(String[] args) {

        Conductor c = new Conductor();
        c.acelerar();


    }

}
