package mar17;

import java.util.Date;

public class Persona {

    private String nombre;
    //private Date fechaNacimiento;
    private int edad;


//    public int decirEdad() {
//        Date hoy = new Date();
//        return 0;//(fechaNacimiento-hoy);
//    }

    public void cumplirAnios() {
        //System.out.println("cumplo anios");
        this.edad++;
    }

    public int getEdad() {
        return edad;
    }

}
