package mar17;

public class Conductor {

    private String nombre;
    private String nroLicencia;

    private Auto auto;

    public void acelerar() {

        auto.incrementarVelocidad();

    }

    public void frenar() {

    }

    public void doblar() {

    }

    public void meterCombustibleEnCilindros() {

    }

}
