package prueba;

public class Mundo {

    public static void main(String[] args) {

        Persona p = new Persona();
        p.nombrar("guido");
        System.out.println(p.decirNombre());

        /*
         * dslkfdkjlf
         * sdfdsfds
         *
         */
        Persona p2 = new Persona();
        p2.nombrar("pedro");
        System.out.println(p2.decirNombre());


        p = p2;

        System.out.println(p);
        System.out.println(p2);

    }

}
