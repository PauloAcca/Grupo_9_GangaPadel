package prueba;

/**
 * Esta es la clase persona
 */
public class Persona {

    private String nombre;
    private String apellido;
    private int dni;
    private int edad;

    public void nombrar(String elnombre) {
        this.nombre = elnombre;
    }

    public String decirNombre() {
        return ponerEnMaytusculas(this.nombre);
    }

    private String ponerEnMaytusculas(String s) {
        return s.toUpperCase();
    }
}
