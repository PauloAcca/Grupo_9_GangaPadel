package abril21.abstractas;

public class IPerro extends Perro{

    @Override
    public String ladrar() {
        return "GUAU GUAU soy " + this.nombre;
    }
}
