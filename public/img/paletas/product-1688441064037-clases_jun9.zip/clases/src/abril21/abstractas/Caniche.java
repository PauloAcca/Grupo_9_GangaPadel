package abril21.abstractas;

public class Caniche extends Perro {

    public String ladrar() {
        return "WIF WIF";
    }



}
