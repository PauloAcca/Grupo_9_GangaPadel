package abril21.abstractas;

import mar17.direccion.Persona;

public abstract class Perro {

    protected String nombre;

    public String comer() {
        return "como granitos del plato";
    }

    public String caminar() {
        return "muevo las patas y me desplazo";
    }

    public abstract String ladrar();

//    public abstract String buscarAlDuenio(Persona p);


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
