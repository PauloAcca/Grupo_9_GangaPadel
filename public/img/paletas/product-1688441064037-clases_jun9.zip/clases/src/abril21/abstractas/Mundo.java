package abril21.abstractas;

public class Mundo {

    public static void main(String[] args) {

//        Perro p = new Perro();
//        System.out.println(p.ladrar());
//
//        Mastin m = new Mastin();
//        m.setNombre("FURIA");
//        System.out.println(m.ladrar());
//
//        Caniche c = new Caniche();
//        System.out.println(c.ladrar());

        Perro[] plaza = new Perro[5];
        plaza[0] = new Caniche();
        plaza[1] = new Mastin();
        plaza[2] = new Husky();
        plaza[3] = new Beagle();
        plaza[4] = new Callejero();

        if(plaza[2] instanceof Callejero) {
            Callejero c = (Callejero) plaza[2];
            System.out.println(c.pelear());
        }

        for (int i = 0; i < plaza.length; i++) {
            if(plaza[i] != null) {
                System.out.println(plaza[i].ladrar());
            }
        }


        IPerro ip = new IPerro();
        ip.setNombre("manchita");

        System.out.println(ip.ladrar());

    }



}
