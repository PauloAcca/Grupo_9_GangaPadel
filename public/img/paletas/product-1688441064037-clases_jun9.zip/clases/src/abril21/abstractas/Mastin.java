package abril21.abstractas;

public class Mastin extends Perro {

    public String ladrar() {
        return "WOOFF WOOFF";
    }

}
