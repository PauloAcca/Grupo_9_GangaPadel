package abril21.abstractas;

public class Callejero extends Perro{

    public String ladrar() {
        return "grrr guau";// + super.ladrar();
    }

    public String comer() {
        return super.comer() + " robandole del plato del perro de al lado";
    }

    public String pelear() {
        return "pelea";
    }

}
