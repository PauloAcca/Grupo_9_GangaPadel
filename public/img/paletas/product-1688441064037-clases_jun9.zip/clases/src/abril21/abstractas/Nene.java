package abril21.abstractas;

import javax.swing.*;

public class Nene {

    public void jugar(Perro p) {
        System.out.println(p.ladrar());
    }

    public static void main(String[] args) {

        Perro p;

        Nene n = new Nene();

        String ingreseTipoPerro = JOptionPane.showInputDialog("ingrese tipo perro");
        if(ingreseTipoPerro.equals("C")) {
            p = new Callejero();
        } else if (ingreseTipoPerro.equals("H")) {
            p = new Husky();
        } else {
            p = new Beagle();
        }
        n.jugar(p);


    }

}
