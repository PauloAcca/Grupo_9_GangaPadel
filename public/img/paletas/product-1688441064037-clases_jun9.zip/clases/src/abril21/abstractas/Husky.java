package abril21.abstractas;

import mar17.direccion.Persona;

public class Husky extends Perro {

    public String ladrar() {
        return "WOOOUuuuu";
    }

    public String ladrar(int volumen) {
        return volumen > 10? "WWWWOUUUUU":"wou";
    }

//    public String buscarAlDuenio() {
//        return null;
//    }
}
