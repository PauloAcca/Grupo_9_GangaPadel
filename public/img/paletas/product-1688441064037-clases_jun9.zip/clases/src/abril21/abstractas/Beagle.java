package abril21.abstractas;

public class Beagle extends Perro {

    @Override
    public String ladrar() {
        return "wwouuf wouf wouf";
    }
}
