package abril21.ejercicio;

public class Persona {
}
