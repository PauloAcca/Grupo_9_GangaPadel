package abril21.ejercicio;

public class Ejecutivo extends Empleado{

}
