package abril21.ejercicio;

public class Main {

    public static void main(String[] args) {
        Empleado[] empresa = new Empleado[10];
        empresa[0] = new Empleado();
        empresa[1] = new Empleado();
        empresa[2] = new Ejecutivo();
        empresa[3] = new Empleado();

        int cantEmpleados = 0;
        int cantEjecutivos = 0;
        for (int i = 0; i < empresa.length; i++) {
            if (empresa[i] instanceof Ejecutivo) {
                cantEjecutivos++;
            } else {
                cantEmpleados++;
            }


        }
    }
}
