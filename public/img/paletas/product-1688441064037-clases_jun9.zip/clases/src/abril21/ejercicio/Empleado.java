package abril21.ejercicio;

public class Empleado extends Persona{
}
