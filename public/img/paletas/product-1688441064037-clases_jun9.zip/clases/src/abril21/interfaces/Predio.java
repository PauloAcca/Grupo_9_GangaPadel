package abril21.interfaces;

public class Predio {

    public static void main(String[] args) {

        Animal g = new Gato();
        Animal p = new Perro();
        Animal t = new Tarantula();
        System.out.println(g.caminar());
        System.out.println(p.caminar());
        System.out.println(t.caminar());

        Animal[] bichos = new Animal[3];
        bichos[0] = g;
        bichos[1] = p;
        bichos[2] = t;

        for (int i = 0; i < bichos.length; i++) {
            if(bichos[i] instanceof Gato) {
                ((Gato)bichos[i]).baniar();
            } else if (bichos[i] instanceof Perro) {
                ((Perro)bichos[i]).baniar();
            }
        }

        Mascota m = new Gato();
        Mascota m2 = new Perro();
        Mascota m3 = new Pou();

        Mascota[] misMascotas = new Mascota[3];
        misMascotas[0] = m;
        misMascotas[1] = m2;
        misMascotas[2] = m3;

        for (int i = 0; i < misMascotas.length; i++) {
            System.out.println(misMascotas[i].baniar());
        }

    }

}
