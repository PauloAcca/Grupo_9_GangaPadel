package abril21.interfaces;

public interface Mascota {

    public String baniar();

    public String jugar();

}
