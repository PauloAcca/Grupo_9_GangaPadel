package abril21.interfaces;

public interface Domestico {


}
