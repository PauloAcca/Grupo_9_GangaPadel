package abril21.interfaces;

public class VideoJuego {

    public void display() {
        System.out.println(".... welcome");
    }

    public void collect() {
        System.out.println("te cobro USD 0.99");
    }
}
