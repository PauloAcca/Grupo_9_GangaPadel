package abril21.interfaces;

public class Pou extends VideoJuego implements Mascota{

    @Override
    public String baniar() {
        return "presionar dos veces el icono de espuma";
    }

    public String jugar() {
        return "juego";
    }
}
