package abril21.interfaces;

public class Tarantula extends Animal{

    public String morder() {
        return "muerde" + this.comer();
    }
}
