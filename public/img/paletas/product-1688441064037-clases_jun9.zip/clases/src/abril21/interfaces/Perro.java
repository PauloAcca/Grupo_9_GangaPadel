package abril21.interfaces;

public class Perro extends Animal implements Mascota{

    public String ladrar(){
        return "guau";
    }

    public String baniar() {
        return "shampoo y agua, baña perro.";
    }

    public String jugar() {
        return "juego con pelota";
    }

}
