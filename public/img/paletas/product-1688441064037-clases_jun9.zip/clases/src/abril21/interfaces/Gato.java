package abril21.interfaces;

public class Gato extends Animal implements Mascota, Domestico{

    public String maullar() {
        return "miau";
    }

    public String baniar() {
        return "qué dificil";
    }

    public String jugar() {
        return "juego con bola de lana";
    }

}
