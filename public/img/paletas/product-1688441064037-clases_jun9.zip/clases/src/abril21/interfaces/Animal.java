package abril21.interfaces;

public abstract class Animal {

    public String comer(){
        return "ingiero comida";
    }

    public String caminar(){
        return "muevo las patas y me desplazo";
    }


}
