package abril21;

import abril14.herencia.Computadora;
import mar17.empresa.Auto;

public class Arreglos {

    public static void main(String[] args) {

        Computadora c = new Computadora();
        System.out.println(c);

        String s = "kljlkj";
//        s.length();
//        s.charAt();
//        s.replace()

        int[] enteros = new int[10]; // [0,1,2,3,4,5,6,7,8,9]
        enteros[3] = 345;
        System.out.println(enteros[2]);

        Integer i = new Integer(12);
        Integer j = new Integer(12);
        System.out.println(i == j);
        System.out.println(i.intValue() == j.intValue());

        Integer[] enteros2 = new Integer[5];
        System.out.println(enteros2[2]);
        enteros2[3] = new Integer(56);
        enteros2[4] = 47;

        Auto[] flota = new Auto[10];
        flota[0] = new Auto();
        flota[0].setMarca("ford");
        Auto zz = flota[0];
        zz.setModelo("ka");

        //System.out.println(flota[10]);

        for (int idx=0; idx < flota.length; idx++) {
            if(flota[idx] != null) {
                System.out.println(flota[idx]);
            }
        }

        /*
        short --- Short
        byte  --- Byte
        char  --- Character
        int   --- Integer
        long  --- Long

        float --- FLoat
        double -- Double

        boolean - Boolean
        */
    }

}
