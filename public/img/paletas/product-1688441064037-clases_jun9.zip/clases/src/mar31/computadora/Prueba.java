package mar31.computadora;

public class Prueba {

    public static void main(String[] args) {

        int i = 3;

        Procesador p = new Procesador();
        p.setMarca("intel");
        p.setModelo("i3");
        p.setVelocidadEnGhz(3);

        Procesador p2 = new Procesador();
        p2.setMarca("amd");
        p2.setModelo("ryzen");
        p2.setVelocidadEnGhz(3);

        DiscoRigido d = new DiscoRigido();
        d.setMarca("seagate");
        d.setModelo("s001");
        d.setCapacidad(1000);

        DiscoRigido d2 = new DiscoRigido();
        d2.setMarca("samsung");
        d2.setModelo("evo5");
        d2.setCapacidad(3000);

        Computadora c = new Computadora();
        c.setDiscoRigido(d);
        c.setProcesador(p);
        c.setMarca("HP");
        c.setModelo("envy");
        c.setGigasRam(4);

        Computadora c2 = new Computadora();
        c2.setMarca("asus");
        c2.setModelo("x515");
        c2.setPrecio(400000);
        c2.setGigasRam(12);
        c2.setProcesador(p2);
        c2.setDiscoRigido(d2);

        System.out.println(c.mostrar());
        System.out.println(c2.mostrar());
        System.out.println();
        c2.setDiscoRigido(c.getDiscoRigido());

        System.out.println(c.mostrar());
        System.out.println(c2.mostrar());

        System.out.println();

        c2.getDiscoRigido().setCapacidad(120);

        System.out.println(c.mostrar());
        System.out.println(c2.mostrar());

        System.out.println(c.encender());

    }
}
