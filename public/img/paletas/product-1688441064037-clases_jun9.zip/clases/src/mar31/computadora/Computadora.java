package mar31.computadora;

public class Computadora {

    private String marca;
    private String modelo;
    private int precio;

    private DiscoRigido discoRigido;
    private Procesador procesador;

    private int gigasRam;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public DiscoRigido getDiscoRigido() {
        return discoRigido;
    }

    public void setDiscoRigido(DiscoRigido discoRigido) {
        this.discoRigido = discoRigido;
    }

    public Procesador getProcesador() {
        return procesador;
    }

    public void setProcesador(Procesador procesador) {
        this.procesador = procesador;
    }

    public int getGigasRam() {
        return gigasRam;
    }

    public void setGigasRam(int gigasRam) {
        this.gigasRam = gigasRam;
    }

    public String mostrar() {
        return "Computadora{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", precio=" + precio +
                ", discoRigido=" + discoRigido.mostrar() +
                ", procesador=" + procesador.mostrar() +
                ", gigasRam=" + gigasRam +
                '}';
    }

    public String encender() {
        String resultado = "";
        resultado += this.discoRigido.arrancar();
        resultado += " "  + this.procesador.encender();
        resultado += " <<< pc encendida";
        return resultado;

    }
}
