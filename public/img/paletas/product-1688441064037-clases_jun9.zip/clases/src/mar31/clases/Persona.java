package mar31.clases;

public class Persona {

    private String nombre;
    private String apellido;
    private int edad;

    public Persona() {

    }

    public Persona(int edad) {
        this.edad = edad;
    }

    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    public Persona(String nombre, String apellido, int edad) {
        this(nombre, apellido);
        this.edad = edad;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String saludar() {
        return "hola";
    }

    public String saludar(Persona p) {
        return "hola como andas " + p.getNombre() + " ?";
    }

    public String saludar(String nombre) {
        return "hola como andas " + nombre + " ?";
    }

    public String saludar(String nombre, String apellido) {
        return "Hola sr/a: " + nombre + " " + apellido + ", como le va ?";
    }


    public String saludar(String nombre, String apellido, String paisOrigen) {
        return this.saludar(nombre, apellido) + " como le va ? yo vengo de la oficina de " + paisOrigen;
    }
}
