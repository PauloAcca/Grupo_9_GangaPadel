package mar31.clases;

public class Prueba {

    public static void main(String[] args) {

        Persona p = new Persona();
        p.setNombre("Guido");
        p.setApellido("Chiesa");
        p.setEdad(41);

        Persona p2 = new Persona("Dario", "Perez");
        p2.setEdad(41);

        Persona p3 = new Persona(30);
        p3.setNombre("Ana");
        p3.setApellido("Garcia");

        System.out.println(p2.saludar());

        System.out.println(p.saludar());
        System.out.println(p2.saludar(p3));
        System.out.println(p3.saludar("carlos", "rodriguez"));
        System.out.println(p.saludar("diana", "deustch", "peru"));

    }

}
