package mar31.auto;

public class Auto {

    private String marca;
    private String modelo;
    private int precio;

    private Motor motor;
    private CajaVelocidades cajaVelocidades;
    private Rueda rueda;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    public CajaVelocidades getCajaVelocidades() {
        return cajaVelocidades;
    }

    public void setCajaVelocidades(CajaVelocidades cajaVelocidades) {
        this.cajaVelocidades = cajaVelocidades;
    }

    public Rueda getRueda() {
        return rueda;
    }

    public void setRueda(Rueda rueda) {
        this.rueda = rueda;
    }

    public String mostrarValores() {
        String s = "Auto{" +
                "marca='" + this.marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", precio=" + precio +
                ", motor tiene marca " + motor.getMarca() +
                ", cajaVelocidades tiene " + cajaVelocidades.getCantidadMarchas() + " marchas" +
                '}';
        return s;
    }
}
