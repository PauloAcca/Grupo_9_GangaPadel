package mar31.auto;

public class CajaVelocidades {

    private String fabricante;
    private char tipoRelacion; // 'c', 'm', 'l'
    private int cantidadMarchas;

    public String setFabricante(String fabricante) {
        return this.fabricante = fabricante;
    }

    public String getFabricante() {
        return fabricante;
    }

    public char getTipoRelacion() {
        return tipoRelacion;
    }

    public void setTipoRelacion(char tipoRelacion) {
        this.tipoRelacion = tipoRelacion;
    }

    public int getCantidadMarchas() {
        return cantidadMarchas;
    }

    public void setCantidadMarchas(int cantidadMarchas) {
        this.cantidadMarchas = cantidadMarchas;
    }
}
