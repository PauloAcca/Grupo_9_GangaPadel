package mar31.auto;

public class Motor {

    private int cilindrada;
    private String marca;
    private int potencia;

    public Motor() {

    }

    public void mostrarValores() {
        System.out.println("El motor de " + this.marca + " tiene cilindrada:" + this.cilindrada + " y potencia de:" + potencia);
    }

    public String verValores() {
        return "El motor de " + this.marca + " tiene cilindrada:" + this.cilindrada + " y potencia de:" + potencia;
    }

//    public void darMarca(String marca) {
//        this.marca = marca;
//    }
//    public String obetnerMarca(String marca) {
//        return this.marca;
//    }
//
//    public void darPotencia(int p) {
//        this.potencia = p;
//    }
//    public int obtenerPotencia(int p) {
//        return this.potencia;
//    }
//
//    public double obtenerCilindrada() {
//        return this.cilindrada/1000;
//    }
//    public double darCilindrada(int cilindradaEnCC) {
//        return this.cilindrada = cilindradaEnCC;
//    }


    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }
}
