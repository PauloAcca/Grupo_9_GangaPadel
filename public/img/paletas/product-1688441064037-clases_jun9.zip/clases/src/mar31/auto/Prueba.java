package mar31.auto;

public class Prueba {


    public static void main(String[] args) {

//        Motor m = new Motor();
//        m.darMarca("FORD");
//        m.darPotencia(100);

//        System.out.println(m.verValores());


        CajaVelocidades c = new CajaVelocidades();
        c.setFabricante("CAjas Cordoba SA");
        c.setCantidadMarchas(5);
        c.setTipoRelacion('m');

        Auto a = new Auto();
        a.setMarca("FORD");
        a.setModelo("KA");
        a.setPrecio(1000000);

        Motor motor1 = new Motor();
        motor1.setMarca("MOTORCRAFT");
        motor1.setCilindrada(1500);
        motor1.setPotencia(100);

        a.setMotor(motor1);
        a.setCajaVelocidades(c);

        System.out.println(a.mostrarValores());

    }

}
