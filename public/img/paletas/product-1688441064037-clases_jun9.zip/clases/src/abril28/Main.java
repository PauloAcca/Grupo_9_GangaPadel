package abril28;

import abril21.ejercicio.Ejecutivo;
import abril21.ejercicio.Empleado;

import java.util.*;

public class Main {

    public static void main(String[] args) {



        Collection<Auto> c = new ArrayList();
        c.add(new Auto("bmw","q5"));
        c.add(new Auto("bmw","318"));
        c.add(new Auto("bmw","q7"));


        List<Auto> l = new LinkedList();
        l.add(new Auto("ford", "ka"));
        Auto a = new Auto("fiat", "kronos");
        l.add(a);
        l.add(a);
        l.add(new Auto("vw", "gol"));
        System.out.println(l.size());

//        Auto b = new Auto("fiat", "kronos");
//        l.remove(b);
//        l.remove(1);

        for (int i = 0; i < l.size(); i++) {
            System.out.println(l.get(i));
        }
        System.out.println("--------------------");
        Set<Auto> autos = new HashSet<>();
        autos.add(new Auto("ford", "ka"));
        Auto x = new Auto("fiat", "kronos");
        autos.add(x);
        autos.add(x);
        autos.add(new Auto("vw", "gol"));

        System.out.println("--------------------");


        for(Iterator<Auto> i = l.listIterator(); i.hasNext();) {
            Auto zz = i.next();
            System.out.println(zz);
        }
        System.out.println("--------de nuevo con foreach------------");
        for(Auto auto: l) {
            System.out.println(auto);
        }
        System.out.println("--------mapas------------");
        Persona p = new Persona("guido", "chiesa");
        Persona q = new Persona("pepe", "gomez");
        Map<Persona, Auto> flota = new HashMap<>();
        flota.put(p, a);
        flota.put(q, x);

        Persona pp = new Persona("guido", "chiesa");
        System.out.println("el auto de guido es");
        System.out.println(flota.get(pp));

        Collection<Auto> autosEnFlota = flota.values();
        for (Auto f: autosEnFlota) {
            System.out.println(f);
        }

        Set<Persona> personas = flota.keySet();
        for (Persona p2: personas) {
            System.out.println(flota.get(p2));

        }

        Set<Map.Entry<Persona, Auto>> entries = flota.entrySet();
        for (Map.Entry<Persona, Auto> entrada:entries) {
            System.out.println(entrada.getKey().getNombre() + " >> " + entrada.getValue().getMarca());
        }

    }
}
