package abril14.herencia;

public class Tablet extends Computadora {

}
