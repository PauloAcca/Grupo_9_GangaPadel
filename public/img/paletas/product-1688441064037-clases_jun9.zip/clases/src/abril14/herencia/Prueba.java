package abril14.herencia;

public class Prueba {

    public static void main(String[] args) {

//        Computadora c = null;
//        System.out.println(c.encender());



        Computadora c1 = new Computadora();
        System.out.println(c1.encender());

        Desktop d = new Desktop();
        System.out.println(d.encender(true, " recuperacion", 70));

        Laptop l1 = new Laptop();
        l1.setMarca("ASUS");
        l1.setModelo("X515");
        l1.setPrecio(400000);
        System.out.println(l1.encender(true));
        System.out.println(l1.abrir());

        Netbook n = new Netbook();
        System.out.println(n.encender(false));

        Computadora c2 = new Laptop();
        c2.setMarca("HP");
        c2.setModelo("ENVY");
        c2.setPrecio(45000);
        System.out.println(c2.encender());
//        System.out.println(c2.abrir());
        Laptop lx = (Laptop)c2;
        System.out.println(lx.abrir());

        if( c1 instanceof Laptop) {
            Laptop lz = (Laptop) c1;
            System.out.println(lz.abrir());
        }


        Computadora x = new Laptop();
        Computadora y = new Desktop();
        Computadora z = new Netbook();

        System.out.println("-------------------");
        System.out.println(x.encender(true));
        System.out.println(y.encender(true));
        System.out.println(z.encender(true));


    }

}
