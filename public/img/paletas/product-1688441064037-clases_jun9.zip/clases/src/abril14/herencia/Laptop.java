package abril14.herencia;

public class Laptop extends Computadora {

    @Override
    public String encender(boolean encendidoRapido) {
        return super.encender(encendidoRapido) + " desde SSD";
    }


    public String abrir() {
        return "se abre la tapa";
    }

    public String cerrar() {
        return "se cierra la tapa";
    }

}
