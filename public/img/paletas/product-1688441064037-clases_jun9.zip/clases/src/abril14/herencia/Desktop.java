package abril14.herencia;

public class Desktop extends Computadora {

    @Override
    public String encender() {
        return " desktop encendida";
    }

    @Override
    public String encender(boolean encendidoRapido) {
        return this.encender() + " L";
    }

    @Override
    public String encender(boolean encendidoRapido, String opcion) {
        return this.encender(encendidoRapido) + " >> " + opcion;
    }

    public String encender(boolean encendidoRapido, String opcion, int volumenInicial) {
        return this.encender(encendidoRapido) + " >> " + opcion + " vol:" + volumenInicial;
    }

}
