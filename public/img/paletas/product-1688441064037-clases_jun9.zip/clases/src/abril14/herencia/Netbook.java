package abril14.herencia;

public class Netbook extends Laptop{

    @Override
    public String encender(boolean encendidoRapido) {
        return super.encender() + " desde TARJETA SD";
    }

}
