package abril14.herencia;

public class Computadora {

    private String marca;
    private String modelo;
    private int precio;

    public String encender() {
        return " <<< computadora encendida ";

    }

    public String encender(boolean encendidoRapido) {
        return " <<< computadora encendida " + (encendidoRapido ? 'R' : 'L');

    }

    public String encender(boolean encendidoRapido, String opcion) {
        return " <<< computadora encendida " + (encendidoRapido ? 'R' : 'L') + " -> opc:"+opcion;

    }

    public String apagar(boolean sleep) {
        return " <<< computadora " + (sleep ? "dormida" : "apagada");
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
}
