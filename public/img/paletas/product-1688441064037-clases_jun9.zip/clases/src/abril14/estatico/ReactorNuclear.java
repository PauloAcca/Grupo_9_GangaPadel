package abril14.estatico;

public class ReactorNuclear {

    private String paisOrigen;
    private String modelo;
    private int salidaMW;
    private int temperaturaOperacion;

    public static final int TEMPERATURA_SEGURIDAD = 1980;

    public ReactorNuclear() {

    }

    public ReactorNuclear(String paisOrigen, String modelo, int salidaMW, int temperaturaOperacion) {
        this.paisOrigen = paisOrigen;
        this.modelo = modelo;
        this.salidaMW = salidaMW;
        this.temperaturaOperacion = temperaturaOperacion;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getSalidaMW() {
        return salidaMW;
    }

    public void setSalidaMW(int salidaMW) {
        this.salidaMW = salidaMW;
    }

    public int getTemperaturaOperacion() {
        return temperaturaOperacion;
    }

    public void setTemperaturaOperacion(int temperaturaOperacion) {
        this.temperaturaOperacion = temperaturaOperacion;
    }

    public String producirEnergia() {
        return "Produciendo energia";
    }

    //si no fuera constante:
    //public static void setTemperaturaSeguridad(int temperaturaSeguridad) {
        //ReactorNuclear.temperaturaSeguridad = temperaturaSeguridad;
    //}

//    public static int getTemperaturaSeguridad() {
//        return ReactorNuclear.temperaturaSeguridad;
//    }

}
