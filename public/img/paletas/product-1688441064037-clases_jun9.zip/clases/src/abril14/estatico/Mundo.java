package abril14.estatico;

public class Mundo {

    public static void main(String[] args) {

        ReactorNuclear r1 = new ReactorNuclear();
        r1.setPaisOrigen("Rusia");
        r1.setModelo("MOSKVA 001");
        r1.setSalidaMW(1000);
        r1.setTemperaturaOperacion(1100);
//        ReactorNuclear.setTemperaturaSeguridad(1600);

        ReactorNuclear r2 = new ReactorNuclear("Francia", "FR001", 700, 900);
//        System.out.println(r2.getTemperaturaSeguridad());
//        r2.setTemperaturaSeguridad(1100);


        ReactorNuclear r3 = new ReactorNuclear("Argentina", "ArgentoX1", 400, 1000);
//        r3.setTemperaturaSeguridad(1600);


        System.out.println(r1.producirEnergia());
        System.out.println(r2.producirEnergia());
        System.out.println(r3.producirEnergia());


        ReactorNuclear r4 = new ReactorNuclear();
        r4.setPaisOrigen("Japon");
        r4.setModelo("KUMITO001");
        r4.setSalidaMW(1100);
        r4.setTemperaturaOperacion(800);
//        r4.setTemperaturaSeguridad(1600);



        ReactorNuclear r5 = new ReactorNuclear();
        r5.setPaisOrigen("USA");
        r5.setModelo("AMERICANZZ01");
        r5.setSalidaMW(2100);
        r5.setTemperaturaOperacion(1100);
        //r5.setTemperaturaSeguridad(1710);

        //ReactorNuclear.temperaturaSeguridad = 2100;

        System.out.println("cual es la temp de seg de TODOS los reactores?");
        System.out.println(ReactorNuclear.TEMPERATURA_SEGURIDAD);


    }

}
