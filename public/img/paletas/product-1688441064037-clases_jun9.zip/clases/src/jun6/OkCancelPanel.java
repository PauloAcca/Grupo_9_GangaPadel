package jun6;

import javax.swing.*;

public class OkCancelPanel extends JPanel {

    private JButton okBtn;
    private JButton cancelBtn;

    public OkCancelPanel() {
        armar();
    }

    private void armar() {
        this.okBtn = new JButton("ACEPTAR");
        this.cancelBtn = new JButton("CANCELAR");
        this.add(okBtn);
        this.add(cancelBtn);
    }

    public JButton getOkBtn() {
        return okBtn;
    }

    public void setOkBtn(JButton okBtn) {
        this.okBtn = okBtn;
    }

    public JButton getCancelBtn() {
        return cancelBtn;
    }

    public void setCancelBtn(JButton cancelBtn) {
        this.cancelBtn = cancelBtn;
    }
}
