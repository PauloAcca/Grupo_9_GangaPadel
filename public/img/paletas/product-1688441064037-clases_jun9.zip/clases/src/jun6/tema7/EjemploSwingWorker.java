package jun6.tema7;


import javax.swing.*;

public class EjemploSwingWorker {
    public static void main(String[] args) {
        JFrame swFrame = new JFrame("Prueba SwingWorker");
        swFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        swFrame.setBounds(100, 100, 500, 500);
        SwingWorkerPanel swPanel = new SwingWorkerPanel();
        swFrame.getContentPane().add(swPanel);
        swFrame.setVisible(true);
    }
}
