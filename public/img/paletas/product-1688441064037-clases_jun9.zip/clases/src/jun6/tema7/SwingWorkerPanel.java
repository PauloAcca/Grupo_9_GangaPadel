package jun6.tema7;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.InputStream;

public class SwingWorkerPanel extends JPanel {

    private JButton botonComun;
    private JButton botonSwingWorker;
    private JButton botonLimpiar;
    private JPanel actividadPanel;

    public SwingWorkerPanel() {
        this.setLayout(new BorderLayout());
        JPanel botonesPanel = new JPanel();
        botonComun = new JButton("Sin SW");
        botonSwingWorker = new JButton("Con SW");
        botonLimpiar = new JButton("Reset");

        botonesPanel.add(botonComun);
        botonesPanel.add(botonSwingWorker);
        botonesPanel.add(botonLimpiar);
        this.add(botonesPanel, BorderLayout.NORTH);

        actividadPanel = new JPanel();
        actividadPanel.setLayout(new BoxLayout(actividadPanel, BoxLayout.Y_AXIS));
        actividadPanel.add(new JLabel("Actividad:"));

        this.add(actividadPanel, BorderLayout.CENTER);

        botonComun.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        for (int i = 1; i <= 4; i++) {
                            try {
                                int cantBytes = leerArchivo();
                                actividadPanel.add(new JLabel("Se leyó el archivo: " + (i) + " veces"));
                                revalidate();
                                repaint();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        actividadPanel.add(new JLabel("TERMINADO"));
                    }
                }
        );
        botonSwingWorker.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        procesarLecturaArchivo();
                    }
                }
        );

        botonLimpiar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actividadPanel.removeAll();
				actividadPanel.add(new JLabel("Actividad:"));
				revalidate();
				repaint();
			}
		});
    }

    private void procesarLecturaArchivo() {
        SwingWorker<Void, String> sw = new SwingWorker<Void, String>() {

            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 1; i <= 4; i++) {
                    leerArchivo();
                    actividadPanel.add(new JLabel("Se leyó el archivo: " + (i) + " veces"));
                    revalidate();
                    repaint();
                }
                actividadPanel.add(new JLabel("TERMINADO"));
                revalidate();
                repaint();
                return null;
            }
        };
        sw.execute();
    }

    private int leerArchivo() throws Exception {
        int cantBytes = 0;
        InputStream is = null;
        try {
            is = new FileInputStream("D:\\archivos\\up\\laboratorio1_ONLINE\\workspace\\codigo_modulos\\etc\\syllabus_lab1.pdf");
            while (is.read() != -1) {
                cantBytes++;
            }
        } finally {
            is.close();
        }
        return cantBytes;
    }

}
