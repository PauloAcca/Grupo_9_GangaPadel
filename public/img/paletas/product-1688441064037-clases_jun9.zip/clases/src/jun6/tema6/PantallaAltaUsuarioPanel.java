package jun6.tema6;




import jun6.tema5.tabla.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaAltaUsuarioPanel extends AbstractPantallaAltaPanel{

    public PantallaAltaUsuarioPanel(PanelManager panelManager) {
        super(panelManager);
    }

    @Override
    public void setCamposPanel() {
        this.camposPanel = new CamposUsuarioPanel(panelManager);
        this.botonesPanel = new UsuarioBotoneraPanel(panelManager);
    }


    @Override
    public void ejecutarAccionOk() {
        System.out.println("mando a grabar usuario");

//        nov12.jdbc.Usuario u = new nov12.jdbc.Usuario();
//        u.setUser(((CamposUsuarioPanel)this.camposPanel).getNombreTxt().getText());
//        u.setEmail("a@a.com");
//        u.setPass("12345");
//        try {
//            UsuarioService s = new UsuarioService();
//            s.agregarUsuario(u);
//        } catch (ServiceException e) {
//            JOptionPane.showMessageDialog(this, "HUBO UN ERROR");
//        }
    }

    @Override
    public void ejecutarAccionCancel() {
        System.out.println("cancelo y presento lista de usuarios");
    }

    public void llenarDatos(Usuario u) {
        CamposUsuarioPanel camposUsuarioPanel = (CamposUsuarioPanel) this.camposPanel;
        camposUsuarioPanel.getNombreTxt().setText(u.getNombre());
        camposUsuarioPanel.getApellidoTxt().setText(String.valueOf(u.getEmail()));
    }

}
