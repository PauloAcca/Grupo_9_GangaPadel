package jun6.tema6;





import jun6.tema5.tabla.Usuario;

import javax.swing.*;

public class PanelManager {

	private JFrame frame;
	private PantallaAltaUsuarioPanel pantallaAltaUsuarioPanel;
	private PantallaAltaCuentaPanel pantallaAltaCuentaPanel;
	private PantallaInicioPanel pantallaInicioPanel;

	public PanelManager() {
		// TODO Auto-generated constructor stub
	}

	public void armarManager() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pantallaAltaUsuarioPanel = new PantallaAltaUsuarioPanel(this);
		pantallaAltaCuentaPanel = new PantallaAltaCuentaPanel(this);
		pantallaInicioPanel = new PantallaInicioPanel(this);
	}

	public void showFrame() {
		frame.setVisible(true);
	}

	public void mostrarInicioPanel() {
		frame.getContentPane().removeAll();
		frame.getContentPane().add(pantallaInicioPanel);
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior

	}

	public void mostrarPantallaAltaUsuarioPanel() {
		frame.getContentPane().removeAll();
		frame.getContentPane().add(pantallaAltaUsuarioPanel);
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior
		
	}


	public void mostrarPantallaEDicionUsuarioPanel(Usuario usuarioAEditar) {
		frame.getContentPane().removeAll();
		frame.getContentPane().add(pantallaAltaUsuarioPanel);
		pantallaAltaUsuarioPanel.llenarDatos(usuarioAEditar);
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior

	}

	public void mostrarPantallaAltaUsuarioPanel(Usuario u) {
		frame.getContentPane().removeAll();
		if(u != null) {
			frame.getContentPane().add(pantallaAltaUsuarioPanel);
		}
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior

	}

	public void mostrarPantallaAltaCuentaPanel() {
		frame.getContentPane().removeAll();
		frame.getContentPane().add(pantallaAltaCuentaPanel);
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior

	}
}
