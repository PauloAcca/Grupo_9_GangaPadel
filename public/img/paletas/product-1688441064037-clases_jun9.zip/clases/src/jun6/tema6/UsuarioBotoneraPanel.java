package jun6.tema6;


public class UsuarioBotoneraPanel extends BotoneraPanel {

    public UsuarioBotoneraPanel(PanelManager p) {
        super(p);
    }

//    @Override
//    public void ejecutarAccionAceptar() {
//        UsuarioService service = new UsuarioService();
//
//        try {
//            service.agregarUsuario(null);
//        } catch () {
//
//        }
//    }
}
