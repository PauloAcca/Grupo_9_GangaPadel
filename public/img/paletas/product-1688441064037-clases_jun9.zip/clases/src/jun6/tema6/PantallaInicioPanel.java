package jun6.tema6;


import jun6.tema5.tabla.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PantallaInicioPanel extends JPanel {

    protected PanelManager panelManager;
    private JButton usuarioBtn;
    private JButton editarUsuarioBtn;
    private JButton cuentaBtn;

    public PantallaInicioPanel(PanelManager panelManager) {
        this.panelManager = panelManager;
        armarPantallaPanel();
    }

    public void armarPantallaPanel() {
        this.setLayout(new FlowLayout());

        this.usuarioBtn = new JButton("alta usuarios");
        this.editarUsuarioBtn = new JButton("editar  usuario");
        this.cuentaBtn = new JButton("alta cuentas");

        this.add(usuarioBtn);
        this.add(editarUsuarioBtn);
        this.add(cuentaBtn);

        //escuchar evento del ok, mandar a grabar
        this.usuarioBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelManager.mostrarPantallaAltaUsuarioPanel();
            }
        });

        this.editarUsuarioBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Usuario usuario = new Usuario();
                usuario.setNombre("pepe");
                usuario.setEmail("pepe@mail.com");
                panelManager.mostrarPantallaEDicionUsuarioPanel(usuario);
            }
        });

        this.cuentaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelManager.mostrarPantallaAltaCuentaPanel();
            }
        });

    }
}
