package jun6.tema6;

import javax.swing.*;
import java.awt.*;

public class CamposUsuarioPanel extends CamposPanel {

	private JTextField nombreTxt;
	private JTextField apellidoTxt;

	public CamposUsuarioPanel(PanelManager panelManager) {
		super(panelManager);
	}
	
	public void armarFormulario() {
		this.setLayout(new GridLayout(2,2));

		JLabel nombreLbl = new JLabel("Nombre:");
		JLabel apellidoLbl = new JLabel("Apellido:");

		nombreTxt = new JTextField("");
		apellidoTxt = new JTextField("");

		this.add(nombreLbl);
		this.add(nombreTxt);
		this.add(apellidoLbl);
		this.add(apellidoTxt);
		
	}

	public JTextField getNombreTxt() {
		return nombreTxt;
	}

	public void setNombreTxt(JTextField nombreTxt) {
		this.nombreTxt = nombreTxt;
	}

	public JTextField getApellidoTxt() {
		return apellidoTxt;
	}

	public void setApellidoTxt(JTextField apellidoTxt) {
		this.apellidoTxt = apellidoTxt;
	}
}
