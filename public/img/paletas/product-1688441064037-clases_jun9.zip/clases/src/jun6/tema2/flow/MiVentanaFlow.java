package jun6.tema2.flow;

import javax.swing.*;
import java.awt.*;

public class MiVentanaFlow {
	
	public MiVentanaFlow() {
		
		armar();
	}

	private void armar() {
		JFrame marco = new JFrame("Prueba de varios tema2.layouts");
		JPanel panelBasico = new JPanel();
		panelBasico.setBorder(BorderFactory.createLineBorder(Color.GREEN));

		JButton boton1 = new JButton("Hola");
		JPanel aux = new JPanel();
		aux.setBorder(BorderFactory.createLineBorder(Color.RED));
		aux.add(boton1);
		panelBasico.setLayout(new FlowLayout());
		panelBasico.add(aux);
		
		JButton boton2 = new JButton("como");
		panelBasico.add(boton2);
		
		JButton boton3 = new JButton("va?");
		panelBasico.add(boton3);
		
		//marco.getContentPane().add(panelBasico);
		//si no usan barra de menu-  equivale a esto:
		marco.add(panelBasico);
		
 		marco.pack();
		marco.setVisible(true);
		
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
