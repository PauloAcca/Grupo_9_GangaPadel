package jun6.tema2.box;


public class EjemploBox {

	public static void main(String[] args) {
		MiVentanaBox box = new MiVentanaBox();
	}
	
}
