package jun6.tema2.border;

import java.awt.*;

import javax.swing.*;

public class MiVentanaBorder {

	public MiVentanaBorder() {
		armar();
	}

	private void armar() {
		JFrame marco = new JFrame("Ejemplo Border layout");
		JPanel panelBasico = new JPanel();
		
		JButton boton1 = new JButton("Norte del horizonte");
		JPanel aux = new JPanel();
		aux.add(boton1);

		panelBasico.setLayout(new BorderLayout());
		panelBasico.add(aux, BorderLayout.NORTH);

		JButton boton2 = new JButton("este");
		panelBasico.add(boton2, BorderLayout.EAST);
		
		JButton boton3 = new JButton("sur");
		panelBasico.add(boton3, BorderLayout.SOUTH);
		
		JButton boton4 = new JButton("oeste");
		panelBasico.add(boton4, BorderLayout.WEST);
		
		JButton boton5 = new JButton("centro");
		JPanel auxCentro = new JPanel();
		auxCentro.add(boton5);
		auxCentro.setBorder(BorderFactory.createLineBorder(Color.BLUE));
		panelBasico.add(auxCentro, BorderLayout.CENTER);
		
		marco.getContentPane().add(panelBasico);
		
		marco.pack();
		marco.setVisible(true);
		
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	
	
}
