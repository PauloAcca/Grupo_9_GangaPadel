package jun6.tema2.border;

public class EjemploBorder {

	public static void main(String[] args) {
		MiVentanaBorder border = new MiVentanaBorder();
		
	}
	
}
