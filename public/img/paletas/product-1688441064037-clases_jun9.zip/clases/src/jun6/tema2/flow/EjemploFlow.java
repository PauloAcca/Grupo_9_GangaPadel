package jun6.tema2.flow;

public class EjemploFlow {

	public static void main(String[] args) {
		MiVentanaFlow flow = new MiVentanaFlow();

	}

}
