package jun6.tema2.grid;

import javax.swing.*;
import java.awt.*;

public class MiVentanaGrid {
	
	public MiVentanaGrid() {
		armar();
	}

	private void armar() {
		JFrame marco = new JFrame();
		JPanel panelBasico = new JPanel();
		
		JButton boton1 = new JButton("Celda 0,0");
		JPanel aux = new JPanel();
		aux.add(boton1);
		aux.setBorder(BorderFactory.createLineBorder(Color.BLUE));
		panelBasico.setLayout(new GridLayout(3,2));//3 filas, 2 cols
		panelBasico.add(aux);
		
		JLabel texto2 = new JLabel("celda 0,1");
		panelBasico.add(texto2);
		
		JLabel label3 = new JLabel("celda 1,0");
		panelBasico.add(label3);
		
		JButton label4 = new JButton("celda 1,1");
		panelBasico.add(label4);
		
		JLabel label5 = new JLabel("celda 2,0");
		JPanel aux5 = new JPanel();
		aux5.add(label5);
		panelBasico.add(aux5);
		
		JLabel label6 = new JLabel("celda 1,2");
		panelBasico.add(label6);
		
		panelBasico.setBackground(Color.yellow);
		
		marco.add(panelBasico);
		
		marco.pack();
		marco.setVisible(true);
		
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
