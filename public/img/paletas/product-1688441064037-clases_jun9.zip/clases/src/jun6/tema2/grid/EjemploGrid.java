package jun6.tema2.grid;

public class EjemploGrid {

	public static void main(String[] args) {
		MiVentanaGrid ppal = new MiVentanaGrid();
		
	}
	
}
