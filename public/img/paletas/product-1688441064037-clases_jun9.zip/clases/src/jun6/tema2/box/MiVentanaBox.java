package jun6.tema2.box;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MiVentanaBox {
	
	public MiVentanaBox() {
		
		armar();
	}

	private void armar() {
		JFrame marco = new JFrame("Prueba de varios tema2.layouts");
		JPanel panelBasico = new JPanel();
		
		BoxLayout caja = new BoxLayout(panelBasico, BoxLayout.X_AXIS);
		panelBasico.setLayout(caja);

		JPanel aux = new JPanel();
		aux.setBorder(BorderFactory.createLineBorder(Color.BLUE));

		JButton boton1 = new JButton("box 1");
		aux.add(boton1);
		
		panelBasico.add(aux);
		
		JLabel texto2 = new JLabel("box 2");
		panelBasico.add(texto2);
		
		JLabel label3 = new JLabel("box 3");
		panelBasico.add(label3);
//		
		JButton label4 = new JButton("box 4");
		panelBasico.add(label4);
		
		
		JPanel aux5 = new JPanel();
		aux5.setLayout(new BoxLayout(aux5, BoxLayout.Y_AXIS));
		aux5.setBorder(BorderFactory.createLineBorder(Color.RED));
		
		JLabel label5 = new JLabel("box 5");
		aux5.add(label5);
		JLabel label6 = new JLabel("box 6");
		aux5.add(label6);

		panelBasico.add(aux5);
		
		marco.getContentPane().add(panelBasico);
		
		marco.pack();
		marco.setVisible(true);
		
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
