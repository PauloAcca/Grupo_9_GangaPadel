package jun6.tema5.tablaEditable;

import javax.swing.JFrame;

public class Ppal {
	
	public static void main(String[] args) {
		JFrame j = new JFrame("Prueba Tablas");
		j.getContentPane().add(new TablaUsuariosPanel());
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.pack();
		j.setVisible(true);
	}

}
