package jun6.tema5.tablaEditable;

import java.util.List;

import javax.swing.table.AbstractTableModel;

public class EjemploTableModel extends AbstractTableModel {

	private List<String> nombreColumnas;
	
	
	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
