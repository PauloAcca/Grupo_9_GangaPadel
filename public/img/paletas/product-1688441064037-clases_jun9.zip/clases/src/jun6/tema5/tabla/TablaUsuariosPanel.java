package jun6.tema5.tabla;



import jun6.tema6.PanelManager;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class TablaUsuariosPanel extends JPanel implements ActionListener, Printable {

    private PanelManager panelManager;
    private JTable tablaUsuarios;
    private UsuarioTableModel modelo;

    private JScrollPane scrollPaneParaTabla;
    private JButton botonLlenar;
    private JButton botonAgregar;
    private JButton botonBorrar;
    private JButton botonEditar;
    private JButton botonImprimir;

    public TablaUsuariosPanel() {
        super();
        armarPanel();
    }

    private void armarPanel() {
        this.setLayout(new FlowLayout());

        modelo = new UsuarioTableModel();
        tablaUsuarios = new JTable(modelo);
        scrollPaneParaTabla = new JScrollPane(tablaUsuarios);
        this.add(scrollPaneParaTabla);

        botonLlenar = new JButton("Cargar Tabla");
        botonLlenar.addActionListener(this);
        this.add(botonLlenar);

        botonBorrar = new JButton("BORRAR");
        botonBorrar.addActionListener(this);
        this.add(botonBorrar);

        botonAgregar = new JButton("Cargar fila");
        botonAgregar.addActionListener(this);
        this.add(botonAgregar);

        botonImprimir = new JButton("Imprimir Tabla");
        botonImprimir.addActionListener(this);
        this.add(botonImprimir);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == botonImprimir) {
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setPrintable(this);
            boolean ok = job.printDialog();
            if (ok) {
                try {
                    job.print();
                } catch (PrinterException ex) {
                    /* The job did not successfully complete */
                }
            }

        } else if (e.getSource() == botonAgregar) {
            Random r = new Random();
            int x = r.nextInt(100);
            int dni = r.nextInt(1000) * r.nextInt(1000);

            Usuario u1 = new Usuario("nombre" + x, "test" + x, "mail" + x, dni);

            modelo.getContenido().add(u1);

            modelo.fireTableDataChanged();


//			 tablaUsuarios.revalidate();
//
//			 this.revalidate(); this.repaint();


        } else if (e.getSource() == botonBorrar) {

            int filaSeleccionada = this.tablaUsuarios.getSelectedRow();

            Usuario usuario = this.modelo.getContenido().get(filaSeleccionada);
            this.modelo.getContenido().remove(filaSeleccionada);

            modelo.fireTableDataChanged();
        } else if (e.getSource() == botonEditar) {

            int filaSeleccionada = this.tablaUsuarios.getSelectedRow();

            Usuario usuario = this.modelo.getContenido().get(filaSeleccionada);

            this.panelManager.mostrarPantallaEDicionUsuarioPanel(usuario);

            this.modelo.getContenido().remove(filaSeleccionada);

            modelo.fireTableDataChanged();
        } else {
            Usuario u1 = new Usuario("pipo", "pipo", "pipo@river.com", 123);
            Usuario u2 = new Usuario("coco", "coco", "coco@boca.com", 456);
            Usuario u3 = new Usuario("tolo", "tolo", "tolo@rojo.com", 789);
            Usuario u4 = new Usuario("boquita", "boquita", "sensini@newells.com", 100);
            List<Usuario> lista = new ArrayList<Usuario>();
            lista.add(u1);
            lista.add(u2);
            lista.add(u3);
            lista.add(u4);
            modelo.setContenido(lista);
            modelo.fireTableDataChanged();

//			UsuarioService service = new UsuarioService();
//			List<Usuario> lista = null;
//			try {
//				lista = service.listarUsuarios();
//
//				modelo.setContenido(lista);
//				modelo.fireTableDataChanged();
//			} catch (ServiceException ex) {
//				ex.printStackTrace();
//			}
        }
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        System.out.println("imprimo");
        return 0;
    }

}
