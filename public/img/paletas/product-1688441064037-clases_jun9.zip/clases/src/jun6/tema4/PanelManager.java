package jun6.tema4;




import jun6.tema5.tabla.Usuario;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PanelManager {

	private JFrame frame;
	private PanelLista panelLista;
	private PanelFormulario panelFormulario;

	public PanelManager() {
	}

	public void armarManager() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		panelLista = new PanelLista(this);
		panelLista.armarPanelLista();

		panelFormulario = new PanelFormulario(this);
		panelFormulario.armarPanelFormulario();

	}

	public void showFrame() {
		frame.setVisible(true);
	}

	public void mostrarSalir() {
		int response = JOptionPane.showConfirmDialog(frame, "Esta seguro?");
		if (response == JOptionPane.OK_OPTION) {
			System.exit(0);
		}
	}

	public void mostrarPanelLista() {
		frame.getContentPane().removeAll();
		frame.getContentPane().add(panelLista);
		frame.getContentPane().validate();
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior

	}

	public void mostrarPanelFormulario() {
		frame.getContentPane().removeAll();
		frame.getContentPane().add(panelFormulario);
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior
	}

	public void mostrarPanelEdicion(Usuario u) {
		
		frame.getContentPane().removeAll();
		frame.getContentPane().add(panelFormulario);
		frame.getContentPane().validate();//RE-dispongo los elementos segun el layout
		frame.getContentPane().repaint();//RE-pinto los elementos dispuestos en el paso anterior
	}

}
