package jun6.tema4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelFormulario extends JPanel {

	private PanelManager manager;
	private JButton aceptarBtn;
	private JLabel label;

	public PanelFormulario(PanelManager m) {
		this.manager = m;
	}
	
	public void armarPanelFormulario() {
		setLayout(new BorderLayout());

		aceptarBtn = new JButton("Aceptar - ir a lista");
		label = new JLabel("Aca va un formulario");
		add(label, BorderLayout.CENTER);
		add(aceptarBtn, BorderLayout.SOUTH);

		aceptarBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("se grabo en base de datos");
				manager.mostrarPanelLista();
			}
		});

	}
}
