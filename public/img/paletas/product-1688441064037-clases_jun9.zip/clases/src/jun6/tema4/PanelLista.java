package jun6.tema4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelLista extends JPanel {

    private PanelManager panelManager;
    private JButton crearBtn;
    private JLabel label;

    public PanelLista(PanelManager m) {
        super();
        this.panelManager = m;
    }

    public void armarPanelLista() {
        this.setLayout(new BorderLayout());
        crearBtn = new JButton("Crear Nuevo");
        label = new JLabel("Aca va una lista");
        add(label, BorderLayout.CENTER);
        add(crearBtn, BorderLayout.SOUTH);


        crearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelManager.mostrarPanelFormulario();
            }
        });
    }
}
