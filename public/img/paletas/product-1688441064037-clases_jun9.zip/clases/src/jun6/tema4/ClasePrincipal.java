package jun6.tema4;

public class ClasePrincipal {
	
	private PanelManager manager;

	public static void main(String[] args) {
		
		ClasePrincipal ppal = new ClasePrincipal();
		ppal.iniciarManager();
		ppal.mostrarFrame();
	}
		
	public void iniciarManager() {
		manager = new PanelManager();
		manager.armarManager();
		manager.mostrarPanelLista();
	}

	public void mostrarFrame() {
		manager.showFrame();
	}

}
