package jun6;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPanel extends JPanel implements ActionListener {

    private LoginForm loginFormPanel;
    private OkCancelPanel botoneraPanel;


    public LoginPanel() {
        armar();
    }
    public void armar() {
        this.loginFormPanel = new LoginForm();
        this.botoneraPanel = new OkCancelPanel();
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        this.add(this.loginFormPanel);
        this.add(this.botoneraPanel);

        this.botoneraPanel.getOkBtn().addActionListener(this);
    }

    public static void main(String[] args) {
        JFrame prueba = new JFrame();
        prueba.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        prueba.pack();
        prueba.setVisible(true);
        prueba.getContentPane().add(new LoginPanel());
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if(actionEvent.getSource() == this.botoneraPanel.getOkBtn()) {
//            UsuarioDAO d = new UsuarioDAoImpl();
//            String user = this.loginFormPanel.getUsernameTxt().getText();
//            String pass = this.loginFormPanel.getPasswordTxt().getText();
//            User u = d.findByUserAndPass(user, pass);
//            if(u != null) {
//                System.out.println("LOGIN EXITOSO");
//            }
        }
    }
}
