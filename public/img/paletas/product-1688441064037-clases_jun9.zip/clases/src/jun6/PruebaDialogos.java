package jun6;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class PruebaDialogos extends JFrame {

	public void mostrar() {
		JOptionPane.showMessageDialog(this, "Mensaje de error",
				"titulo ventana error", JOptionPane.ERROR_MESSAGE);
		
		JOptionPane.showMessageDialog(this, "Mensaje informacion",
				"titulo ventana info", JOptionPane.INFORMATION_MESSAGE);
		
		JOptionPane.showMessageDialog(this, "Mensaje de alerta",
				"titulo ventana alert", JOptionPane.WARNING_MESSAGE);
		
		JOptionPane.showMessageDialog(this, "Mensaje de pregunta",
				"titulo ventana pregunta", JOptionPane.QUESTION_MESSAGE);
		
		JOptionPane.showMessageDialog(this, "Mensaje comun", "titulo ventana ",
				JOptionPane.PLAIN_MESSAGE);

		
		int resultado1 = JOptionPane.showConfirmDialog(this,
				"Esta seguro de...", "Confirmacion 1", JOptionPane.YES_NO_OPTION);
		
		int resultado2 = JOptionPane.showConfirmDialog(this,
				"Esta seguro de...", "Confirmacion 2",
				JOptionPane.YES_NO_CANCEL_OPTION);
		
		int resultado3 = JOptionPane.showConfirmDialog(this,
				"Esta seguro de...", "Confirmacion 3",
				JOptionPane.OK_CANCEL_OPTION);

		if(resultado1 == JOptionPane.YES_OPTION) {
			System.out.println("el usuario dijo si a la confirmaicon 1");
		}
		if(resultado1 == JOptionPane.NO_OPTION) {
			System.out.println("el usuario dijo no a la confirmacion 1");
		}
		if(resultado2 == JOptionPane.YES_OPTION) {
			System.out.println("el usuario dijo si a la confirmaicon 2");
		}
		if(resultado2 == JOptionPane.NO_OPTION) {
			System.out.println("el usuario dijo no a la confirmacion 2");
		}
		if(resultado2 == JOptionPane.CANCEL_OPTION) {
			System.out.println("el usuario dijo cancelar a la confirmacion 2");
		}
		if(resultado3 == JOptionPane.OK_OPTION) {
			System.out.println("el usuario dijo OK a la confirmaicon 3");
		}
		if(resultado3 == JOptionPane.CANCEL_OPTION) {
			System.out.println("el usuario dijo cancelar a la confirmacion 3");
		}
		
		
	}

	public static void main(String argv[]) {
		PruebaDialogos p = new PruebaDialogos();
		p.mostrar();
	}
}
