package jun6.tema3.listenerBasico;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class HolaMundoPanelBasico extends JPanel implements ActionListener{

	private JButton botonHola;
	private JButton botonChau;
	private JTextField nombreTxt;

	public HolaMundoPanelBasico() {

	}

	public void armar() {
		this.setLayout(new FlowLayout());
		this.botonHola = new JButton("Hola!!");
		this.botonChau = new JButton("Chau!!");
		JLabel nombreLbl = new JLabel("ingrese el nombre");
		this.nombreTxt = new JTextField(10);
		this.add(nombreLbl);
		this.add(nombreTxt);
		this.add(botonHola);
		this.add(botonChau);
		botonHola.addActionListener(this);
		botonChau.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.botonHola) {
			String nombreIgresado = this.nombreTxt.getText();
			System.out.println("Hola, "+nombreIgresado+", como va todo	?");
		}
		if(e.getSource() == this.botonChau) {
			String nombreIgresado = this.nombreTxt.getText();
			System.out.println("Chau, "+nombreIgresado+", nos vemos");
		}
	}
}
