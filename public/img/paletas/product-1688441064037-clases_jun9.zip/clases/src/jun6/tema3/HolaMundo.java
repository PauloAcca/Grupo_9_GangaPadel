package jun6.tema3;



import jun6.tema3.listenerAnonimo.HolaMundoPanelAnonimo;
import jun6.tema3.listenerBasico.HolaMundoPanelBasico;

import javax.swing.JFrame;


public class HolaMundo {
	public static void main(String[] args) {
		JFrame ppala = new JFrame("Prueba listener");
//		HolaMundoPanelBasico hpa = new HolaMundoPanelBasico();
		HolaMundoPanelAnonimo hpa = new HolaMundoPanelAnonimo();
//		hpa.armar();
		ppala.getContentPane().add(hpa);
		
		ppala.pack();
		ppala.setVisible(true);
		
		ppala.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}
