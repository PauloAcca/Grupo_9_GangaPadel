package jun6.tema3.listenerAnonimo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HolaMundoPanelAnonimo extends JPanel {

    private JButton botonHola;
	private JTextField nombreTxt;

    public HolaMundoPanelAnonimo() {
        this.setLayout(new FlowLayout());
        this.botonHola = new JButton("Hola!!");
		JLabel nombreLbl = new JLabel("ingrese el nombre");
		this.nombreTxt = new JTextField(30);
		this.add(nombreLbl);
		this.add(nombreTxt);
		this.add(botonHola);
        botonHola.addActionListener(
			new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String nombreIgresado = nombreTxt.getText();
					System.out.println("Hola, "+nombreIgresado+", como va todo?");
				}
			}
        );
    }

	public JButton getBotonHola() {
		return botonHola;
	}

	public void setBotonHola(JButton botonHola) {
		this.botonHola = botonHola;
	}

	public JTextField getNombreTxt() {
		return nombreTxt;
	}

	public void setNombreTxt(JTextField nombreTxt) {
		this.nombreTxt = nombreTxt;
	}
}
