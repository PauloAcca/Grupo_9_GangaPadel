package may12.ejemplo;

import may12.excepciones.AutoException;
import may12.excepciones.InyeccionException;

public class PistaCarreras {

    public static void main(String[] args) {

        Auto a = new Auto();
        Motor m = new Motor();
        Carburador c = new Carburador();
        m.setCarburador(c);

        try {
            System.out.println(a.acelerar());
        } catch (AutoException miExcepcion) {
            miExcepcion.printStackTrace();
//            System.out.println(miExcepcion.getMessage());
//            System.out.println(" no se pudo completar el acelerar");
        } catch (InyeccionException miExcepcion) {
            System.out.println("UPA");
//            System.out.println(miExcepcion.getMessage());
//            System.out.println(" no se pudo completar el acelerar");
        } catch (Exception miExcepcion) {
            System.out.println("error inesperado");
//            System.out.println(miExcepcion.getMessage());
//            System.out.println(" no se pudo completar el acelerar");
        } finally {
            System.out.println("termine");
        }



    }

}
