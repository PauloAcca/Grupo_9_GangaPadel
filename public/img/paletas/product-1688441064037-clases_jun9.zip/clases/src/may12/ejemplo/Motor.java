package may12.ejemplo;

import may12.excepciones.CombustibleException;

public class Motor {

    private int cantCombutible;
    private Carburador carburador;

    public String aumentarRpm() throws CombustibleException{
        if(cantCombutible <= 0) {
            throw new CombustibleException("no alcanza la cant combustible");
        } else {
            return "MAS RPM -> " + carburador.inyectarCombustible();
        }
    }

    public Carburador getCarburador() {
        return carburador;
    }

    public void setCarburador(Carburador carburador) {
        this.carburador = carburador;
    }
}
