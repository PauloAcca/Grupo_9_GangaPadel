package may12.ejemplo;

import may12.excepciones.InyeccionException;

public class Carburador {

    private int cantBocas;
    private int capacidad;

    public String inyectarCombustible() {
        if(capacidad <= 0) {
            throw new InyeccionException();
        } else {
            return "meto combustible a los cilindros";
        }
    }

    public int getCantBocas() {
        return cantBocas;
    }

    public void setCantBocas(int cantBocas) {
        this.cantBocas = cantBocas;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
}
