package may12.ejemplo;

import may12.excepciones.AutoException;
import may12.excepciones.CombustibleException;

public class Auto {

    private Motor motor;

    public String acelerar() throws AutoException {
        try {
            String aumento = this.motor.aumentarRpm();
            return aumento;
        } catch (CombustibleException e) {
            throw new AutoException("NO SE PUEDE ACELERAR", e);
        }
//        System.out.println("hola");

    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }
}
