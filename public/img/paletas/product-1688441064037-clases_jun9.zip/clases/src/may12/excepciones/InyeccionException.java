package may12.excepciones;

public class InyeccionException extends RuntimeException {

    public InyeccionException() {
    }

    public InyeccionException(String s) {
        super(s);
    }

    public InyeccionException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public InyeccionException(Throwable throwable) {
        super(throwable);
    }
}
