package may12.excepciones;

public class CombustibleException extends Exception {

    public CombustibleException() {
    }

    public CombustibleException(String s) {
        super(s);
    }

    public CombustibleException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CombustibleException(Throwable throwable) {
        super(throwable);
    }
}
