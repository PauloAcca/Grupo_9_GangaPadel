package may12.excepciones;

public class AutoException extends Exception {

    public AutoException() {
    }

    public AutoException(String s) {
        super(s);
    }

    public AutoException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public AutoException(Throwable throwable) {
        super(throwable);
    }
}
